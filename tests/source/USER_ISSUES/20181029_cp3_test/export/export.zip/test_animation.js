(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"test_animation_atlas_", frames: [[0,0,800,800],[664,802,513,859],[1669,840,322,178],[802,0,800,800],[1669,1126,225,80],[1179,802,488,641],[1179,1445,658,234],[0,802,662,875],[1669,1020,190,104],[1669,454,310,384],[1604,0,438,452]]}
];


// symbols:



(lib.CachedTexturedBitmap_1 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_10 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_11 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_2 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_4 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_5 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_6 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_7 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_8 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_9 = function() {
	this.initialize(ss["test_animation_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.teacher = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_10
	this.instance = new lib.CachedTexturedBitmap_3();
	this.instance.parent = this;
	this.instance.setTransform(-193.45,-328.15,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_9
	this.instance_1 = new lib.CachedTexturedBitmap_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-244.45,-177.1,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_6
	this.instance_2 = new lib.CachedTexturedBitmap_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-271.1,4.45,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer_5
	this.instance_3 = new lib.CachedTexturedBitmap_6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-282.25,-242.75,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Layer_4
	this.instance_4 = new lib.CachedTexturedBitmap_7();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-181.55,-269,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Layer_3
	this.instance_5 = new lib.CachedTexturedBitmap_8();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-212.55,-354.4,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Hair
	this.instance_6 = new lib.CachedTexturedBitmap_9();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-231.8,-386.45,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// Layer_7
	this.instance_7 = new lib.CachedTexturedBitmap_10();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-247,49.65,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// Layer_8
	this.instance_8 = new lib.CachedTexturedBitmap_11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-202.25,328.7,0.3501,0.3501);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-282.2,-386.4,241.5,777.4);


(lib.Scene_1_White = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// White
	this.instance = new lib.CachedTexturedBitmap_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Outline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Outline
	this.instance = new lib.CachedTexturedBitmap_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Content = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Content
	this.instance = new lib.teacher("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(194.3,941.4,1.4282,1.4282,0,0,0,-160,1.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:590.4},23,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.CP3_animation_test = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_23 = function() {
		this.___loopingOver___ = true;
		stage.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(23).call(this.frame_23).wait(1));

	// Outline_obj_
	this.Outline = new lib.Scene_1_Outline();
	this.Outline.name = "Outline";
	this.Outline.parent = this;
	this.Outline.setTransform(200,200,1,1,0,0,0,200,200);
	this.Outline.depth = 0;
	this.Outline.isAttachedToCamera = 0
	this.Outline.isAttachedToMask = 0
	this.Outline.layerDepth = 0
	this.Outline.layerIndex = 0
	this.Outline.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Outline).wait(24));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Az4T4QoPoPAArpQAAroIPoQQIPoPLpAAQLpAAIPIPQIQIQAALoQAALpoQIPQoPIQrpAAQrpAAoPoQg");
	mask.setTransform(200,200);

	// Content_obj_
	this.Content = new lib.Scene_1_Content();
	this.Content.name = "Content";
	this.Content.parent = this;
	this.Content.setTransform(192.2,942.1,1,1,0,0,0,192.2,942.1);
	this.Content.depth = 0;
	this.Content.isAttachedToCamera = 0
	this.Content.isAttachedToMask = 0
	this.Content.layerDepth = 0
	this.Content.layerIndex = 1
	this.Content.maskLayerName = 0

	var maskedShapeInstanceList = [this.Content];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Content).wait(24));

	// White_obj_
	this.White = new lib.Scene_1_White();
	this.White.name = "White";
	this.White.parent = this;
	this.White.setTransform(200,200,1,1,0,0,0,200,200);
	this.White.depth = 0;
	this.White.isAttachedToCamera = 0
	this.White.isAttachedToMask = 0
	this.White.layerDepth = 0
	this.White.layerIndex = 2
	this.White.maskLayerName = 0

	var maskedShapeInstanceList = [this.White];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.White).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(200,200,200,200);
// library properties:
lib.properties = {
	id: '5C0328E4FF2D98498970D62C2851A4A0',
	width: 400,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [
		{src:"images/test_animation_atlas_.png", id:"test_animation_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5C0328E4FF2D98498970D62C2851A4A0'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;